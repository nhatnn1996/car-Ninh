const Footer = () => {
    return (
        <div className="">
            <div className="">
                <img src="/images/logo-footer.png" alt="" className="w-[190px] h-[140px]"/>
            </div>
        </div>
    );
};
export default Footer;